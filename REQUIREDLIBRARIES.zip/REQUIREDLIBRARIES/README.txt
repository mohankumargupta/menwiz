STEP 1 (Destructive Act)
Need to remove LiquidCrystal that comes with Arduino (located at C:\Program Files\ArduinoXXX\libraries)

STEP 2 
Copy these libaries to C:\Program Files\ArduinoXXX\libraries
 